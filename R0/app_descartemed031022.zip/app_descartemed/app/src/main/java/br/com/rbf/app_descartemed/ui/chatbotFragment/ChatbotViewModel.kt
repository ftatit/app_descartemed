package br.com.rbf.app_descartemed.ui.chatbotFragment

import androidx.lifecycle.ViewModel

class ChatbotViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}